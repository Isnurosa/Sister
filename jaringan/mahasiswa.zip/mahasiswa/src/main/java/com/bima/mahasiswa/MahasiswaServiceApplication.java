package com.bima.mahasiswa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MahasiswaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MahasiswaServiceApplication.class, args);
	}

}
